import React, { useState } from 'react'
import logo from '../src/img/logo.jpg'
import axios from 'axios'
import { useSelector } from 'react-redux'
import { selectip } from './features/ipSlice'
import { toast } from 'react-toastify'


function Login({setreload, reload, serverIP, newSocket}) {

    //axios.defaults.withCredentials = true
    const ip = useSelector(selectip)

    const [passkey, setpasskey] = useState(0)
    const handleLogin =async()=>{
        try {
            await axios.post(`http://${ip?.ip }:7700/staffLogin`, {passkey}).then((res)=>{
                //console.log(res);
                
                if(res.data.status === 'success'){                    
                    newSocket.emit("join_room", {room: res.data.verify?.title})

                    const getinfo = JSON.stringify(res.data.verify)
                    sessionStorage.setItem('staffID', getinfo)
                    sessionStorage.setItem('accessToken', res.data.accessToken)
                    sessionStorage.setItem('refreshToken', res.data.refreshToken)
                    setreload(reload + 1)
                }else{
                    toast.error(res.data.message)
                }
            })
        } catch (error) {
            console.log(error);
        } 
    }


  return (
    <div className='login_container'>
        <div className='login_container_body' >
            <img src={logo} alt='' />

            <h3>ENTER STAFF PASSKEY</h3>

            <input onChange={(e)=>setpasskey(e.target.value)} type='number' placeholder='Enter Your Passkey'  />

            <button onClick={handleLogin} >LOGIN</button>
        </div>
    </div>
  )
}

export default Login